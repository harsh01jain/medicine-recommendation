import json
import os
import traceback
import urllib

import firebase_admin
import numpy as np
import pandas as pd
import requests  # Import the standard requests library
from google.auth.transport import requests as google_requests  # Rename Google Auth's requests module if needed
from urllib.parse import quote, unquote
from firebase_admin import credentials, auth
from datetime import datetime, timedelta
import logging
from flask import Flask, request, flash, render_template, redirect, url_for, session, jsonify
from flask_cors import CORS
from flask_mail import Mail, Message
from flask_mysqldb import MySQL
from flask_wtf import FlaskForm
# from google.auth.transport import requests
from google.oauth2 import id_token
from keras.src.saving import load_model
from sklearn.preprocessing import StandardScaler
from sqlalchemy.sql.functions import user
from werkzeug.security import generate_password_hash, check_password_hash
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.urandom(24)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
app.logger.setLevel(logging.INFO)

@app.after_request
def add_headers(response):
    response.headers["Cross-Origin-Resource-Policy"] = "same-origin"
    response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
    return response


# MySQL Configuration
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'admin'
app.config['MYSQL_DB'] = 'curewise'

# Mail Configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'jharsh2501@gmail.com'
app.config['MAIL_PASSWORD'] = 'yhba lqua ussv hrtr'

mysql = MySQL(app)
mail = Mail(app)
OLLAMA_URL = "http://127.0.0.1:11434"

JWT_SECRET = app.config['SECRET_KEY']
JWT_ALGORITHM = 'HS256'

# Google OAuth Configuration
GOOGLE_CLIENT_ID = "390958011372-r63ek69tb2ruukt6quq168epk6a84vm1.apps.googleusercontent.com"

# Firebase Admin initialization
cred = credentials.Certificate(r"C:\Users\Harsh\Downloads\login-4cac5-firebase-adminsdk-2bhgl-b1804f98fb.json")  # Path to your Firebase service account file
firebase_admin.initialize_app(cred)
# Load ML model
MILD_MODEL_PATH = r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\multi_label_disease_model1.h5"
MODERATE_MODEL_PATH = r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\multi_label_disease_model2.h5"
SEVERE_MODEL_PATH =r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\multi_label_disease_model3.h5"

mild_model = load_model(MILD_MODEL_PATH)
moderate_model = load_model(MODERATE_MODEL_PATH)
severe_model = load_model(SEVERE_MODEL_PATH)

# Load data from CSV files
description_df = pd.read_csv(r"C:\Users\Harsh\Downloads\Disease_description.csv")
diet_df = pd.read_csv(r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\Diseases_with_Diet_Plans.csv")
workout_df = pd.read_csv(r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\Diseases_with_Workout_Plans.csv")
Medicine_df = pd.read_csv(r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\medicine.csv",
    encoding='latin1')
# Merge all four dataframes
disease_data = (
    description_df
    .merge(diet_df, on='disease')
    .merge(workout_df, on='disease')
    .merge(Medicine_df, on='disease')
)


class SignupForm(FlaskForm):
    name = StringField('Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign Up')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Log In')

    def validate_email(self, email):
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email.data,))
        user = cur.fetchone()
        cur.close()

if not user:
            raise ValidationError('Email not found.')



def preprocess_input(symptoms_list, symptom_columns):
    """
    Convert a list of symptoms into a binary input vector.
    Handles user input by stripping out prefixes like 'Symptom_' for easier usability,
    but maintains the correct mapping internally for model predictions.
    """
    # Remove the 'Symptom_' prefix for easier comparison
    clean_symptom_mapping = {col.replace("Symptom_", ""): col for col in symptom_columns}

    # Initialize input vector with zeros
    input_vector = np.zeros(len(symptom_columns))

    for symptom in symptoms_list:
        # Check if the symptom (cleaned) exists in the mapping
        if symptom in clean_symptom_mapping:
            # Get the original column name and index from symptom_columns
            original_col_name = clean_symptom_mapping[symptom]
            index = symptom_columns.get_loc(original_col_name)
            input_vector[index] = 1  # Mark the symptom as present

    return input_vector


mild_data = pd.read_csv(r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\level1.csv")
moderate_data = pd.read_csv(r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\level2.csv")
severe_data = pd.read_csv(r"C:\Users\Harsh\Downloads\archive (32)\data_science01\medicine_ty\level3.csv")

mild_symptom_columns = mild_data.columns[mild_data.columns.str.startswith('Symptom_')]
moderate_symptom_columns = moderate_data.columns[moderate_data.columns.str.startswith('Symptom_')]
severe_symptom_columns = severe_data.columns[severe_data.columns.str.startswith('Symptom_')]

mild_disease_columns = mild_data.columns[mild_data.columns.str.startswith('Disease_')]
moderate_disease_columns = moderate_data.columns[moderate_data.columns.str.startswith('Disease_')]
severe_disease_columns = severe_data.columns[severe_data.columns.str.startswith('Disease_')]

# Separate StandardScaler for each dataset
mild_scaler = StandardScaler()
mild_scaler.fit(mild_data.iloc[:, :len(mild_symptom_columns)])

moderate_scaler = StandardScaler()
moderate_scaler.fit(moderate_data.iloc[:, :len(moderate_symptom_columns)])

severe_scaler = StandardScaler()
severe_scaler.fit(severe_data.iloc[:, :len(severe_symptom_columns)])


@app.route('/')
def index():
    if 'id' not in session:
        return redirect(url_for('landing'))  # Redirect to landing page if not logged in

    # Retrieve the name of the logged-in user
    cur = mysql.connection.cursor()
    cur.execute("SELECT name FROM users WHERE id = %s", (session['id'],))
    user = cur.fetchone()  # Fetch the logged-in user's details
    cur.close()

    # Display the dashboard dynamically with user's name injected
    return render_template('index.html', user_name=user[0])



@app.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()
    if form.validate_on_submit():
        name = form.name.data
        email = form.email.data
        password = form.password.data

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()

        if user:
            flash('Email already exists. Please use a different email.', 'danger')
        else:
            hashed_password = generate_password_hash(password)
            cur.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, hashed_password))
            mysql.connection.commit()
            flash('Account created successfully. Please log in.', 'success')
            return redirect(url_for('login'))

        cur.close()

    return render_template('signup.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()

        if not user:
            flash('Please sign up first before logging in.', 'warning')
            return redirect(url_for('signup'))
        elif check_password_hash(user[3], password):
            session['id'] = user[0]
            flash('Logged in successfully.', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid email or password.', 'danger')

    return render_template('login.html', form=form)


@app.route('/login/google', methods=['POST'])
def login_google():
    token = request.json.get('token')

    # Debugging: Log the received token
    app.logger.info(f"Received token: {token}")
    if not token:
        return {'success': False, 'message': 'No token provided.'}, 400

    try:
        # Verify the token using Firebase Admin SDK
        id_info = id_token.verify_oauth2_token(token, requests.Request(), GOOGLE_CLIENT_ID)

        # Debugging: Log the decoded token information
        app.logger.info(f"Decoded token: {id_info}")

        # Extract user details
        email = id_info.get('email')
        name = id_info.get('name', 'User')
        email_verified = id_info.get('email_verified', False)

        if not email or not email_verified:
            return {'success': False, 'message': 'Email not verified or unavailable.'}, 400

        # Check if user exists in the database or create a new user
        cur = mysql.connection.cursor()
        cur.execute(""" 
            INSERT INTO users (name, email) 
            VALUES (%s, %s) 
            ON DUPLICATE KEY UPDATE name=VALUES(name)
        """, (name, email))
        mysql.connection.commit()

        cur.execute("SELECT id FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()

        # Save user ID in session
        session['id'] = user[0]

        return {'success': True, 'message': 'Logged in successfully.'}, 200

    except ValueError as e:
        app.logger.error(f"Google OAuth ValueError: {e}")
        return {'success': False, 'message': 'Invalid Google token.'}, 400

    except Exception as e:
        app.logger.error(f"Unexpected error: {e}")
        return {'success': False, 'message': 'An unexpected error occurred.'}, 500



@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']

        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()

        if user:
            payload = {
                'email': email,
                'exp': int((datetime.utcnow() + timedelta(hours=1)).timestamp())  # Ensure exp is an integer
            }
            jwt_instance = JsonWebToken(['HS256'])
            token = jwt_instance.encode({'alg': 'HS256'}, payload, JWT_SECRET)
            token = token.decode('utf-8')  # Ensure the token is a string

            reset_url = url_for('reset_password', token=quote(token), _external=True)
            app.logger.info(f"Generated reset URL: {reset_url}")  # Log the reset URL for debugging

            msg = Message(
                'Password Reset Request',
                sender='jharsh2501@gmail.com',
                recipients=[email]
            )
            msg.body = f'Click the link to reset your password: {reset_url}'
            mail.send(msg)

            flash('Password reset link sent to your email.', 'info')
        else:
            flash('Email not found.', 'danger')

        cur.close()

    return render_template('forgot_password.html')




@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    try:
        token = unquote(token)  # Decode the URL-encoded token
        jwt_instance = JsonWebToken(['HS256'])
        payload = jwt_instance.decode(token, JWT_SECRET)

        # Log token details for debugging
        app.logger.info(f"Decoded JWT payload: {payload}")
        app.logger.info(f"Current UTC time: {int(datetime.utcnow().timestamp())}")

        if 'exp' in payload and datetime.utcnow() > datetime.utcfromtimestamp(payload['exp']):
            flash('The reset link has expired.', 'danger')
            return redirect(url_for('forgot_password'))

        email = payload['email']

        if request.method == 'POST':
            new_password = request.form.get('password')
            hashed_password = generate_password_hash(new_password)

            cur = mysql.connection.cursor()
            cur.execute("UPDATE users SET password = %s WHERE email = %s", (hashed_password, email))
            mysql.connection.commit()
            cur.close()

            flash('Password updated successfully. Please log in.', 'success')
            return redirect(url_for('login'))

    except Exception as e:
        app.logger.error(f"Reset password error: {e}")
        flash('Invalid reset link. Please try again.', 'danger')
        return redirect(url_for('forgot_password'))

    return render_template('reset_password.html')


@app.route('/submit_symptoms', methods=['POST'])
def submit_symptoms():
    # Ensure the user is logged in
    if 'id' not in session:
        app.logger.warning("Unauthorized access attempt. User not logged in.")
        return jsonify({"success": False, "error": "Please log in to proceed."}), 403

    try:
        # Extract symptoms and severity level from JSON payload
        data = request.get_json()
        symptoms = data.get('symptoms', [])
        severity_level = data.get('severity', '1')  # Default to '1' (Mild)

        # Log raw input for debugging
        app.logger.info(f"Raw symptoms provided: {symptoms}")
        app.logger.info(f"Raw severity level provided: {severity_level}")

        # Clean symptoms by stripping whitespaces & removing empty entries
        symptoms = [symptom.strip() for symptom in symptoms if symptom.strip()]
        app.logger.info(f"Cleaned symptoms: {symptoms}")

        # Map textual severity levels to numeric equivalents
        severity_mapping = {'1': '1', '2': '2', '3': '3'}
        severity_level = severity_mapping.get(severity_level, None)

        if severity_level not in ['1', '2', '3']:
            app.logger.warning("Validation failed: Invalid severity level selected.")
            return jsonify({"success": False, "error": "Invalid severity level selected."}), 400

        # Validation
        if severity_level == '1' and len(symptoms) != 3:  # Mild requires exactly 3 symptoms
            app.logger.warning(f"Validation failed: Mild severity requires exactly 3 symptoms. Provided: {len(symptoms)}")
            return jsonify({"success": False, "error": f"Mild severity requires exactly 3 symptoms. You provided {len(symptoms)}."}), 400
        elif severity_level == '3' and len(symptoms) != 6:  # Severe requires exactly 6 symptoms
            app.logger.warning(f"Validation failed: Severe severity requires exactly 6 symptoms. Provided: {len(symptoms)}")
            return jsonify({"success": False, "error": f"Severe severity requires exactly 6 symptoms. You provided {len(symptoms)}."}), 400
        elif not symptoms:
            app.logger.warning("Validation failed: No symptoms were provided.")
            return jsonify({"success": False, "error": "Please select at least one symptom."}), 400

        # Model selection based on severity
        if severity_level == '1':  # Mild severity
            app.logger.info("Using Mild severity model and resources.")
            input_vector = preprocess_input(symptoms, mild_symptom_columns)
            input_vector_df = pd.DataFrame([input_vector], columns=mild_symptom_columns)
            input_vector_scaled = mild_scaler.transform(input_vector_df)
            predictions = mild_model.predict(input_vector_scaled)
            disease_columns = mild_disease_columns

        elif severity_level == '2':  # Moderate severity
            app.logger.info("Using Moderate severity model and resources.")
            input_vector = preprocess_input(symptoms, moderate_symptom_columns)
            input_vector_df = pd.DataFrame([input_vector], columns=moderate_symptom_columns)
            input_vector_scaled = moderate_scaler.transform(input_vector_df)
            predictions = moderate_model.predict(input_vector_scaled)
            disease_columns = moderate_disease_columns

        elif severity_level == '3':  # Severe severity
            app.logger.info("Using Severe severity model and resources.")
            input_vector = preprocess_input(symptoms, severe_symptom_columns)
            input_vector_df = pd.DataFrame([input_vector], columns=severe_symptom_columns)
            input_vector_scaled = severe_scaler.transform(input_vector_df)
            predictions = severe_model.predict(input_vector_scaled)
            disease_columns = severe_disease_columns

        # Log the selected resources for debugging
        app.logger.info(f"Selected model resources: symptom columns: {disease_columns}")

        # Define a threshold for confident prediction
        threshold = 0.2
        app.logger.info(f"Prediction threshold: {threshold}")

        # Filter predictions above the threshold
        predicted_diseases = [
            disease_columns[i].replace("Disease_", "")  # Clean up disease names
            for i in range(len(predictions[0]))
            if predictions[0][i] > threshold
        ]
        app.logger.info(f"Filtered disease predictions: {predicted_diseases}")

        # Normalize the Disease column in disease_data for matching
        disease_data['Normalized_Disease'] = disease_data['disease'].str.strip().str.lower()
        # Log normalized diseases in the DataFrame
        app.logger.info(f"Normalized diseases in DataFrame: {disease_data['Normalized_Disease'].unique()}")

        # Normalize predicted diseases for robust matching
        predicted_diseases = [disease.strip().lower() for disease in predicted_diseases]
        # Log normalized predicted diseases
        app.logger.info(f"Normalized predicted diseases: {predicted_diseases}")

        # Map predicted diseases to their details
        mapped_data = []
        for disease in predicted_diseases:
            filtered_data = disease_data[disease_data['Normalized_Disease'] == disease]

            if not filtered_data.empty:
                details = filtered_data.iloc[0]
                mapped_data.append({
                    "disease": details['disease'],  # Original disease name
                    "description": details['Description'],  # Matches "Description" column
                })
            else:
                app.logger.error(f"No details found for the predicted disease: {disease}")

        # Return the mapped data
        return jsonify({"success": True, "data": mapped_data}), 200

    except Exception as e:
        app.logger.exception("An error occurred while processing symptoms.")
        return jsonify({"success": False, "error": "An unexpected error occurred. Please try again later."}), 500


@app.route('/disease/description', methods=['POST'])
def fetch_disease_description():
    try:
        # Ensure user is logged in
        if 'id' not in session:
            return jsonify({"success": False, "error": "Please log in to proceed."}), 403

        # Extract diseases from the request payload
        data = request.get_json()
        diseases = data.get('diseases', [])
        diseases = [disease.strip().lower() for disease in diseases if disease.strip()]

        if not diseases:
            return jsonify({"success": False, "error": "Please provide at least one disease."}), 400

        # Debugging: Print disease_data columns
        print("Columns in disease_data:", disease_data.columns)

        # Normalize and map descriptions
        disease_data['Normalized_Disease'] = disease_data['disease'].str.strip().str.lower()
        result = []
        for disease in diseases:
            filtered = disease_data[disease_data['Normalized_Disease'] == disease]

            # Debugging: Print filtered data
            print(f"Filtered data for {disease}:\n", filtered)

            if not filtered.empty:
                result.append({
                    "disease": filtered.iloc[0]['disease'],
                    "description": filtered.iloc[0].get('Description', 'No description available'),
                    "cause": filtered.iloc[0]['Cause'] if pd.notna(filtered.iloc[0]['Cause']) else 'No cause available',
                    "management": filtered.iloc[0]['Management'] if pd.notna(filtered.iloc[0]['Management']) else 'No management available'

                })
            else:
                result.append({
                    "disease": disease,
                    "description": "No description available",
                    "cause": "No cause available",
                    "management": "No management available"
                })

        return jsonify({"success": True, "data": result}), 200

    except Exception as e:
        app.logger.exception("Error fetching disease descriptions.")
        print("Exception:", str(e))  # Debugging: Print exception details
        return jsonify({"success": False, "error": "An unexpected error occurred."}), 500


@app.route('/disease/diet', methods=['POST'])
def fetch_disease_diet():
    try:
        # Ensure user is logged in
        if 'id' not in session:
            return jsonify({"success": False, "error": "Please log in to proceed."}), 403

        # Extract diseases from the request payload
        data = request.get_json()
        diseases = data.get('diseases', [])
        diseases = [disease.strip().lower() for disease in diseases if disease.strip()]

        if not diseases:
            return jsonify({"success": False, "error": "Please provide at least one disease."}), 400

        # Add debug logging
        print("Received disease:", diseases)  # Debug log
        print("Disease data columns:", disease_data.columns.tolist())  # Debug log

        # Normalize and map diets
        disease_data['Normalized_Disease'] = disease_data['disease'].str.strip().str.lower()
        result = []
        for disease in diseases:
            filtered = disease_data[disease_data['Normalized_Disease'] == disease]
            print(f"Filtered data for {disease}:", filtered)  # Debug log

            if not filtered.empty:
                result.append({
                    "disease": filtered.iloc[0]['disease'],
                    "diet": filtered.iloc[0].get('Diet Plan', 'No diet information available'),
                    "Additional Information": filtered.iloc[0]['Additional Information'] if pd.notna(filtered.iloc[0]['Management']) else 'No management available'
                })
            else:
                result.append({
                    "disease": disease,
                    "diet": "No diet information available",
                    "Additional Information": "No Additional Information available"
                })

        print("Result:", result)  # Debug log
        return jsonify({"success": True, "data": result}), 200

    except Exception as e:
        app.logger.exception("Error fetching disease diets.")
        return jsonify({"success": False, "error": "An unexpected error occurred."}), 500


@app.route('/disease/workout', methods=['POST'])
def fetch_disease_workout():
    try:
        # Ensure user is logged in
        if 'id' not in session:
            return jsonify({"success": False, "error": "Please log in to proceed."}), 403

        # Extract disease from the request payload
        data = request.get_json()
        disease = data.get('disease')

        if not disease:
            return jsonify({"success": False, "error": "Please provide a disease."}), 400

        # Normalize and find workout
        disease = disease.strip().lower()
        disease_data['Normalized_Disease'] = disease_data['disease'].str.strip().str.lower()
        filtered = disease_data[disease_data['Normalized_Disease'] == disease]

        if not filtered.empty:
            result = {
                "disease": filtered.iloc[0]['disease'],
                "workout": filtered.iloc[0].get('Workout Plan', 'No workout suggestions available'),
            }
        else:
            result = {
                "disease": disease,
                "workout": "No workout suggestions available for this condition",
            }

        return jsonify({"success": True, "data": result}), 200

    except Exception as e:
        app.logger.exception("Error fetching workout plan.")
        return jsonify({"success": False, "error": "An unexpected error occurred."}), 500

from authlib.jose import JsonWebToken

def generate_reset_token(email):
    jwt_instance = JsonWebToken(['HS256'])
    payload = {
        'email': email,
        'exp': datetime.utcnow() + timedelta(hours=1)
    }
    header = {'alg': 'HS256'}
    token = jwt_instance.encode(header, payload, JWT_SECRET)
    return token


@app.route('/disease/medicine', methods=['POST'])
def fetch_disease_medicine():
    try:
        # Ensure user is logged in
        if 'id' not in session:
            return jsonify({"success": False, "error": "Please log in to proceed."}), 403

        # Extract disease from the request payload
        data = request.get_json()
        disease = data.get('disease')

        if not disease:
            return jsonify({"success": False, "error": "Please provide a disease."}), 400

        # Normalize and find medicine
        disease = disease.strip().lower()
        disease_data['Normalized_Disease'] = disease_data['disease'].str.strip().str.lower()
        filtered = disease_data[disease_data['Normalized_Disease'] == disease]

        if not filtered.empty:
            result = {
                "disease": filtered.iloc[0]['disease'],
                "medicine": filtered.iloc[0].get('Medicines', 'No medicine suggestions available'),
            }
        else:
            result = {
                "disease": disease,
                "medicine": "No medicine suggestions available for this condition",
            }

        return jsonify({"success": True, "data": result}), 200

    except Exception as e:
        app.logger.exception("Error fetching medicine recommendations.")
        return jsonify({"success": False, "error": "An unexpected error occurred."}), 500


@app.route('/logout')
def logout():
    session.pop('id', None)
    flash('Logged out successfully.', 'success')
    return redirect(url_for('landing'))

@app.route('/landing')
def landing():
    return render_template('landing.html')

@app.route('/severity_selection')
def severity_selection():
    return render_template('severity_selection.html')

@app.route('/medicine')
def medicine():
    return render_template('medicine_prediction.html')

@app.route('/mild')
def mild():
    return render_template('severity_mild.html')

@app.route('/moderate')
def moderate():
    return render_template('severity_moderate.html')

@app.route('/diet')
def diet():
    return render_template('diet.html')

@app.route('/workout')
def workout():
    return render_template('workout.html')

@app.route('/description')
def description():
    return render_template('description.html')

@app.route('/severe')
def severe():
    return render_template('severity_severe.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/chatbot')
def chatbot():
    return render_template('chatbot.html')


@app.route('/generate', methods=['POST'])
def generate():
    data = request.json
    prompt = data.get("prompt", "")
    if not prompt:
        return jsonify({"error": "Prompt is required"}), 400

    # Enhanced classification prompt with better examples and clearer criteria
    classification_prompt = f"""Analyze if the following query is medical-related. A query is medical if it relates to:

    1. Medical conditions and diseases (cancer, diabetes, acne, etc.)
    2. Symptoms and health concerns
    3. Treatments and medications
    4. Human body and health
    5. Healthcare and medical procedures
    6. Mental health conditions
    7. Preventive care and wellness
    8. Medical terminology and concepts

    Current query: "{prompt}"

    First, identify the main topic(s) in the query.
    Then, determine if any of these topics fall under medical categories.
    Finally, respond with only 'medical' or 'non-medical'.
    """

    # Get classification from the model
    classification_response = requests.post(f"{OLLAMA_URL}/v1/completions", json={
        "model": "deepseek-r1:7b",
        "prompt": classification_prompt,
        "max_tokens": 50,
        "temperature": 0.1
    })

    # Process the classification response more carefully
    classification_text = classification_response.json().get('response', '').strip().lower()
    is_medical = 'medical' in classification_text.split()

    if not is_medical:
        # Double-check common medical terms that might have been missed
        common_medical_conditions = {
            'cancer', 'tumor', 'acne', 'diabetes', 'asthma', 'arthritis',
            'depression', 'anxiety', 'adhd', 'migraine', 'allergy', 'infection',
            'flu', 'cold', 'covid', 'virus', 'bacterial', 'syndrome'
        }

        # Check if any common medical condition is mentioned in the prompt
        if any(condition in prompt.lower() for condition in common_medical_conditions):
            is_medical = True

    if not is_medical:
        return jsonify({
            "error": "This API only handles medical-related queries. Please ensure your question is about health, medical conditions, treatments, or related topics."
        }), 400

    # Enhanced medical prompt template
    modified_prompt = f"""As a medical information assistant, provide information about:

Query: {prompt}

Requirements:
- Provide accurate, evidence-based medical information
- Keep response under 40 words
- Focus on key medical facts and explanations
- Include relevant medical context
- Be clear and precise in medical terminology

Response:"""

    # Get the medical response
    response = requests.post(f"{OLLAMA_URL}/v1/completions", json={
        "model": "deepseek-r1:7b",
        "prompt": modified_prompt,
        "max_tokens": 1000,
        "temperature": 0.7
    })

    # Process the response
    response_data = response.json()
    if 'response' in response_data:
        response_data['disclaimer'] = (
            "This information is for educational purposes only and not a substitute "
            "for professional medical advice. Please consult a healthcare provider "
            "for personal medical decisions."
        )
        response_data['context_verified'] = True

    return response_data




@app.route('/contact')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(host='192.168.0.100', port=5000, debug=True)


