
app = Flask(_name_)

# Replace with your actual DeepSeek (OLLAMA) API URL
OLLAMA_URL = "http://127.0.0.1:11434"

def correct_text(text: str) -> str:
    spell = SpellChecker()
    corrected_words = []
    for word in text.split():
        if word.lower() in spell or len(word) < 3:
            corrected_words.append(word)
        else:
            corrected = spell.correction(word)
            corrected_words.append(corrected if corrected else word)
    return " ".join(corrected_words)

def create_analysis_prompt(text: str) -> str:
    """
    Instruct DeepSeek to identify 6 categories:
      - medicine
      - disease
      - symptom
      - diet
      - workout
      - personal
    Return them in JSON format with those 6 keys.
    """
    example_text = """Example:
Text: "Patient Name: Jenny Harris, Age: 41, Sex: Female, Phone: 123-456-7890. 
She is taking Aspirin daily for heart condition. She has symptoms of chest pain and shortness of breath. 
She is also recommended to do daily running exercise and reduce salt intake in diet."

JSON output:
{
    "medicine": ["Aspirin"],
    "disease": ["heart condition"],
    "symptom": ["chest pain", "shortness of breath"],
    "diet": ["salt intake"],
    "workout": ["running exercise"],
    "personal": ["Name: Jenny Harris", "Age: 41", "Sex: Female", "Phone: 123-456-7890"]
}
"""
    prompt = f"""
You are a specialized medical NLP assistant.
We want 6 categories in JSON: "medicine", "disease", "symptom", "diet", "workout", and "personal".
"personal" includes name, phone, address, age, sex, or other personal info.

Example:
{example_text}

Now analyze this text:
\"\"\"{text}\"\"\"

Return a JSON with exactly these 6 keys, e.g.:
{{
  "medicine": [],
  "disease": [],
  "symptom": [],
  "diet": [],
  "workout": [],
  "personal": []
}}
"""
    return prompt.strip()

def fuzzy_find_all_substrings(original_text: str, phrase: str, threshold=0.8):
    # Direct substring matching (ignoring threshold)
    intervals = []
    text_lower = original_text.lower()
    phrase_lower = phrase.lower()
    start_index = 0
    while True:
        found_index = text_lower.find(phrase_lower, start_index)
        if found_index == -1:
            break
        end_index = found_index + len(phrase)
        intervals.append((found_index, end_index))
        start_index = end_index
    return intervals

def highlight_text(original_text: str, categories: dict) -> str:
    """
    Highlight recognized terms in the original text using direct substring matching.
    """
    color_map = {
        "medicine": "#ff7f7f",  # Red
        "disease": "#ff7fff",   # Purple
        "symptom": "#ffbf7f",   # Orange
        "diet": "#7fff7f",      # Green
        "workout": "#7fbfff",   # Blue,
        "personal": "#d3d3d3"   # Gray, if used
    }

    highlight_intervals = []
    for cat, terms in categories.items():
        for term in set(terms):
            term_strip = term.strip()
            if not term_strip:
                continue
            intervals = fuzzy_find_all_substrings(original_text, term_strip)
            for (start_idx, end_idx) in intervals:
                highlight_intervals.append((start_idx, end_idx, cat))

    highlight_intervals.sort(key=lambda x: x[0])
    highlighted = []
    last_pos = 0
    for (start, end, cat) in highlight_intervals:
        if start > last_pos:
            highlighted.append(original_text[last_pos:start])
        span_text = original_text[start:end]
        color = color_map.get(cat, "#d3d3d3")
        highlighted.append(f'<span style="background-color: {color};">{span_text}</span>')
        last_pos = end
    if last_pos < len(original_text):
        highlighted.append(original_text[last_pos:])
    return "".join(highlighted)

@app.route('/')
def index():
    return render_template('ocr.html')

@app.route('/ocr', methods=['GET', 'POST'])
def ocr():
    if request.method == 'GET':
        return render_template('ocr.html')

    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400

        image_data = file.read()

        # pen-to-print-handwriting-ocr API
        url = "https://pen-to-print-handwriting-ocr.p.rapidapi.com/recognize/"
        data = {"Session": "string", "includeSubScan": "0"}
        files = {"srcImg": (file.filename, image_data, file.content_type)}
        headers = {
            "x-rapidapi-key": "556416b211msh6d16ba5d7e43f47p1a3386jsn6181f7e78f71",
            "x-rapidapi-host": "pen-to-print-handwriting-ocr.p.rapidapi.com",
            "Accept": "application/json"
        }
        response = requests.post(url, headers=headers, data=data, files=files, timeout=200)
        if response.status_code == 200:
            result = response.json()
            return jsonify({
                "text": result.get("value", "No text extracted"),
                "success": True
            })
        else:
            return jsonify({
                "error": f"API Error: {response.text}",
                "success": False
            }), response.status_code

    except Exception as e:
        return jsonify({"error": str(e), "success": False}), 500

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.json
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "Text is required"}), 400

    try:
        # 1) Correct text
        corrected_text = correct_text(text)

        # 2) Construct prompt for 6 categories
        prompt = create_analysis_prompt(corrected_text)

        # 3) Ask DeepSeek
        response = requests.post(
            f"{OLLAMA_URL}/v1/completions",
            json={
                "model": "deepseek-r1:7b",
                "prompt": prompt,
                "max_tokens": 1000,
                "temperature": 0.3
            },
            timeout=200
        )
        response_data = response.json()

        model_response = response_data.get("response", "")
        if not model_response and "choices" in response_data and response_data["choices"]:
            model_response = response_data["choices"][0].get("text", "")

        # 4) Extract JSON
        json_match = re.search(r'\{[\s\S]*\}', model_response)
        if not json_match:
            # No valid JSON
            empty_categories = {
                "medicine": [],
                "disease": [],
                "symptom": [],
                "diet": [],
                "workout": []
            }
            return jsonify({
                "highlighted_text": text,
                "categories": empty_categories,
                "legend": {
                    "medicine": "#ff7f7f",
                    "disease": "#ff7fff",
                    "symptom": "#ffbf7f",
                    "diet": "#7fff7f",
                    "workout": "#7fbfff"
                },
                "warning": "No valid JSON found in model response."
            })

        # 5) Parse the model's JSON
        categories = {
            "medicine": [],
            "disease": [],
            "symptom": [],
            "diet": [],
            "workout": [],
            "personal": []
        }
        try:
            parsed_data = json.loads(json_match.group())
            for cat in categories.keys():
                if cat in parsed_data and isinstance(parsed_data[cat], list):
                    # remove duplicates / trim
                    unique_list = list(set(parsed_data[cat]))
                    categories[cat] = [u.strip() for u in unique_list if u.strip()]
        except Exception as e:
            print("JSON parsing error:", e)

        # 6) Highlight
        highlighted_text = highlight_text(text, categories)

        # 7) Build final response
        #    We'll store the standard 5 in "categories"
        #    and only add "personal" if not empty
        standard_cats = {
            "medicine": categories["medicine"],
            "disease": categories["disease"],
            "symptom": categories["symptom"],
            "diet": categories["diet"],
            "workout": categories["workout"]
        }

        color_map = {
            "medicine": "#ff7f7f",
            "disease": "#ff7fff",
            "symptom": "#ffbf7f",
            "diet": "#7fff7f",
            "workout": "#7fbfff"
        }

        result = {
            "highlighted_text": highlighted_text,
            "categories": standard_cats,
            "legend": color_map
        }

        # If personal is not empty, we can do two approaches:
        #   Option A: Merge into categories
        #   Option B: Return as separate "personal" key
        # We'll do Option B so your front-end can handle it distinctly:
        if categories["personal"]:
            result["personal"] = categories["personal"]
            # If you want a color for personal highlights:
            result["legend"]["personal"] = "#d3d3d3"

        return jsonify(result)

    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Failed to process request"}), 500
